package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.recyclerview.Adapters.EmailAdapter;
import com.example.recyclerview.model.Email;

public class OpenEmail extends AppCompatActivity {

    public TextView nameTV;
    public TextView subjectTV;
    public TextView bodyTV;
    public ScrollView bodySV;
    public EditText bodyResponse;
    public ImageButton respondButton;
    public ImageButton deleteButton;
    public String BodySV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_email);

        Email curEmail = getIntent().getParcelableExtra("email");
        int pos = getIntent().getIntExtra("PoS", 0);
        String Nametv = curEmail.getName();
        String Subjecttv = curEmail.getSubject();
        BodySV = curEmail.getBody();

//        final Bundle params = this.getIntent().getExtras();
//
//        String Nametv = params.getString("Name");
//        String Subjecttv = params.getString("Subject");
//        String BodySV = params.getParcelable("email").getBody();
//        int pos = params.getInt("PoS");
        nameTV = findViewById(R.id.openedName_tv);
        subjectTV = findViewById(R.id.openedSubject_tv);
        bodyTV = findViewById(R.id.openedBody);
        bodySV = findViewById(R.id.bodyScroll);
        bodyResponse = findViewById(R.id.respondBody);
        respondButton = findViewById(R.id.doneBtn);
        deleteButton = findViewById(R.id.deleteButton);

        nameTV.setText(Nametv);
        subjectTV.setText(Subjecttv);
        bodyTV.setText(BodySV);

        readEmail(pos);
    }

    private void readEmail(int position) {
        respondButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent readEmailIntent = new Intent(OpenEmail.this, MainActivity.class);
                readEmailIntent.putExtra("PoS", position);
                if (!bodyResponse.getText().toString().equals("")){
                    BodySV = bodyResponse.getText().toString();
                }
                Email emailBeingSent = new Email(nameTV.getText().toString(),
                        subjectTV.getText().toString(),
                        BodySV, "https://purepng.com/public/uploads/large/purepng.com-mail-iconsymbolsiconsapple-iosiosios-8-iconsios-8-721522596075clftr.png", true);
                readEmailIntent.putExtra("emailResponded", emailBeingSent);
                nameTV.setTypeface(null, Typeface.NORMAL);
                subjectTV.setTypeface(null, Typeface.NORMAL);
//                BodySV.setTypeface(null, Typeface.NORMAL);
                setResult(RESULT_OK, readEmailIntent);
                finish();
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OpenEmail.this, MainActivity.class);
                intent.putExtra("removePos", position);
                setResult(5, intent);
                finish();
            }
        });
    }
}