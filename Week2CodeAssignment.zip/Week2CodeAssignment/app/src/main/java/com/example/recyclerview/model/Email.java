package com.example.recyclerview.model;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.RequiresApi;

public class Email implements Parcelable {
    private String name;
    private String subject;
    private String body;
    private String imageUrl;
    private boolean hasBeenRead;

    public Email(String name, String subject, String body, String imageUrl, boolean weReadIt) {
        this.name = name;
        this.subject = subject;
        this.body = body;
        this.imageUrl = imageUrl;
        this.hasBeenRead = weReadIt;

    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    protected Email(Parcel in) {
        name = in.readString();
        subject = in.readString();
        body = in.readString();
        imageUrl = in.readString();
        hasBeenRead = in.readBoolean();
    }

    public boolean isHasBeenRead() {
        return hasBeenRead;
    }

    public void setHasBeenRead(boolean hasBeenRead) {
        this.hasBeenRead = hasBeenRead;
    }

    public static final Creator<Email> CREATOR = new Creator<Email>() {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public Email createFromParcel(Parcel in) {
            return new Email(in);
        }

        @Override
        public Email[] newArray(int size) {
            return new Email[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(subject);
        dest.writeString(body);
        dest.writeString(imageUrl);
        dest.writeBoolean(hasBeenRead);
    }
}
